echo "#" > test; echo "#" >> test; echo "#" >> test
